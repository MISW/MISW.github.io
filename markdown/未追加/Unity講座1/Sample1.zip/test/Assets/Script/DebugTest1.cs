﻿using UnityEngine;
using System.Collections;

public class DebugTest : MonoBehaviour {

	// Use this for initialization
	void Start () {

		Debug.Log ("Hello World!");

	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
